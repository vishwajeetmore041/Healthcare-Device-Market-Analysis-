# Quick Start Guide

Welcome to the Market Opportunity Analysis project! This guide will help you get started quickly.

## Prerequisites

- **Python 3.8 or higher**
- **Google Chrome browser** (latest version)
- **Windows, macOS, or Linux**

## Installation

1. **Clone or download the project**:
   ```bash
   cd c:\project
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Verify installation**:
   ```bash
   python -c "import selenium, pandas, sklearn; print('All dependencies installed successfully!')"
   ```

## Quick Start

### Option 1: Run Complete Pipeline (Recommended)
```bash
python main.py --mode all
```
This will:
- Scrape gym data from Justdial
- Clean and process the data
- Generate market analysis
- Create lead scoring model
- Produce actionable recommendations

**Expected time**: 20-30 minutes
**Expected output**: 1000+ businesses analyzed

### Option 2: Run Individual Steps

1. **Scrape data only**:
   ```bash
   python main.py --mode scrape --phase 4
   ```

2. **Process existing data**:
   ```bash
   python main.py --mode process
   ```

3. **Generate market analysis**:
   ```bash
   python main.py --mode analyze
   ```

4. **Create lead scores**:
   ```bash
   python main.py --mode score
   ```

## Understanding the Output

After running the pipeline, you'll find these key files:

### 📊 **Interactive Dashboard**
- **File**: `data/output/interactive_dashboard.html`
- **Purpose**: Visual market overview with charts and filters
- **Usage**: Open in web browser for interactive exploration

### 📈 **Market Analysis Report**
- **File**: `data/output/market_analysis_report.json`
- **Purpose**: Comprehensive market insights and statistics
- **Key Metrics**: Total market size, competition analysis, opportunities

### 🎯 **Sales Recommendations**
- **File**: `data/output/sales_recommendations.json`
- **Purpose**: Prioritized list of prospects with sales strategies
- **Contents**: Priority targets, quick wins, sales approaches

### 📋 **Scored Leads**
- **File**: `data/output/scored_leads.csv`
- **Purpose**: Complete list of businesses with lead scores
- **Columns**: Business info, lead score, priority tier, category

## Example Results

### Top Priority Targets
```
1. Gold's Gym Baner (Score: 9.2/10)
   - Strategy: Direct approach - emphasize innovation
   - Factors: Strong performance, tech-ready, established

2. Fitness First Koregaon Park (Score: 8.9/10)
   - Strategy: Consultative approach - enhance success
   - Factors: High rating, premium location, modern

3. Cult.fit Aundh (Score: 8.7/10)
   - Strategy: Direct approach - competitive advantage
   - Factors: Tech-forward, good ratings, growth potential
```

### Market Insights
- **Total addressable market**: ~500 gyms in Pune
- **Primary targets**: 120 traditional gyms and health clubs
- **Immediate opportunities**: 85 businesses with scores >7.0
- **Market gaps**: Underserved areas in Wakad, Hadapsar

## Customization

### Different Cities
```bash
python main.py --mode all --city "Mumbai" --search-term "Gyms"
```

### Different Business Types
```bash
python main.py --mode all --city "Pune" --search-term "Fitness Centers"
```

## Troubleshooting

### Common Issues

1. **ChromeDriver Error**:
   - Update Chrome browser to latest version
   - Restart the script (webdriver-manager will handle compatibility)

2. **No Results Found**:
   - Check internet connection
   - Try different search terms
   - Run Phase 4 scraper specifically

3. **Permission Errors**:
   - Run as administrator (Windows)
   - Check folder permissions
   - Ensure antivirus isn't blocking files

### Getting Help

1. **Check logs**: `data/output/pipeline.log`
2. **Enable debug mode**: Add `--debug` flag
3. **Review technical guide**: `docs/TECHNICAL_GUIDE.md`

## Next Steps

1. **Review Results**: Start with the interactive dashboard
2. **Prioritize Prospects**: Use the scored leads CSV
3. **Plan Sales Approach**: Follow recommendations in JSON file
4. **Regular Updates**: Re-run monthly for fresh data

## Advanced Usage

### Custom Lead Scoring
```python
from analysis.lead_scorer import FitnessLeadScorer
scorer = FitnessLeadScorer()
# Modify scoring weights
scorer.scoring_weights['technology_readiness_score'] = 0.30
scorer.scoring_weights['rating_score'] = 0.20
```

### Extended Analysis
```python
from analysis.market_analysis import FitnessMarketAnalyzer
analyzer = FitnessMarketAnalyzer('data/output/pune_gyms_final.csv')
# Generate custom insights
insights = analyzer.generate_business_insights()
```

## Business Impact

This analysis enables you to:
- **Prioritize sales efforts** on highest-potential prospects
- **Understand market landscape** and competition
- **Identify underserved areas** for expansion
- **Develop targeted sales strategies** for different business types
- **Track market changes** over time

## Success Metrics

Track these KPIs:
- **Conversion rate** from scored leads
- **Sales cycle time** for priority targets
- **Revenue per prospect** by lead score tier
- **Market penetration** in identified opportunity areas

---

**Ready to start?** Run `python main.py --mode all` and begin your market analysis!