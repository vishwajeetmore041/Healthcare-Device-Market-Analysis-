"""
Phase 1: Basic Web Scraping with Requests and BeautifulSoup

This script demonstrates the initial approach using traditional web scraping methods.
It will likely fail with Justdial due to JavaScript rendering, but serves as an 
educational example of why more advanced techniques are needed.

Expected Result: Limited or no data extraction due to dynamic content loading
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import logging
from urllib.parse import urljoin, quote_plus

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class BasicJustdialScraper:
    def __init__(self):
        self.base_url = "https://www.justdial.com"
        self.session = requests.Session()
        
        # Set headers to mimic a real browser
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
        
        self.results = []
    
    def search_gyms(self, city="Pune", search_term="Gyms"):
        """
        Attempt to search for gyms using direct URL construction
        """
        try:
            # Construct search URL
            encoded_search = quote_plus(search_term)
            encoded_city = quote_plus(city)
            search_url = f"{self.base_url}/{encoded_city}/{encoded_search}"
            
            logger.info(f"Attempting to scrape: {search_url}")
            
            # Make request
            response = self.session.get(search_url, timeout=10)
            response.raise_for_status()
            
            logger.info(f"Response status: {response.status_code}")
            logger.info(f"Response content length: {len(response.content)}")
            
            # Parse HTML
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Save raw HTML for analysis
            with open('data/raw/phase1_raw_response.html', 'w', encoding='utf-8') as f:
                f.write(soup.prettify())
            
            # Look for common business listing patterns
            self._extract_business_data(soup)
            
            return True
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return False
    
    def _extract_business_data(self, soup):
        """
        Attempt to extract business information from the parsed HTML
        """
        logger.info("Analyzing HTML structure for business data...")
        
        # Common selectors that might contain business listings
        potential_selectors = [
            '.result-box',
            '.srp-tuple',
            '.business-listing',
            '.listing-item',
            '[data-business-name]',
            '.store-details',
            '.comp-text'
        ]
        
        businesses_found = 0
        
        for selector in potential_selectors:
            elements = soup.select(selector)
            if elements:
                logger.info(f"Found {len(elements)} elements with selector: {selector}")
                
                for element in elements[:5]:  # Analyze first 5 elements
                    business_info = self._parse_business_element(element)
                    if business_info:
                        self.results.append(business_info)
                        businesses_found += 1
        
        # If no specific selectors work, try to find any div with business-like content
        if businesses_found == 0:
            self._fallback_extraction(soup)
        
        logger.info(f"Total businesses extracted: {len(self.results)}")
    
    def _parse_business_element(self, element):
        """
        Extract business information from a single element
        """
        try:
            # Try to find business name
            name_selectors = ['h3', 'h4', '.business-name', '.store-name', 'a[title]']
            business_name = None
            
            for selector in name_selectors:
                name_elem = element.select_one(selector)
                if name_elem:
                    business_name = name_elem.get_text(strip=True)
                    if business_name and len(business_name) > 3:
                        break
            
            # Try to find rating
            rating_selectors = ['.rating', '.star-rating', '[data-rating]', '.review-score']
            rating = None
            
            for selector in rating_selectors:
                rating_elem = element.select_one(selector)
                if rating_elem:
                    rating_text = rating_elem.get_text(strip=True)
                    # Extract numeric rating
                    import re
                    rating_match = re.search(r'(\d+\.?\d*)', rating_text)
                    if rating_match:
                        rating = float(rating_match.group(1))
                        break
            
            # Try to find address
            address_selectors = ['.address', '.location', '.addr', 'address']
            address = None
            
            for selector in address_selectors:
                addr_elem = element.select_one(selector)
                if addr_elem:
                    address = addr_elem.get_text(strip=True)
                    if address and len(address) > 10:
                        break
            
            if business_name:
                return {
                    'business_name': business_name,
                    'rating': rating,
                    'address': address,
                    'extraction_method': 'structured'
                }
            
        except Exception as e:
            logger.debug(f"Error parsing business element: {e}")
        
        return None
    
    def _fallback_extraction(self, soup):
        """
        Fallback method to extract any business-like information
        """
        logger.info("Attempting fallback extraction...")
        
        # Look for any text that might be business names
        all_text = soup.get_text()
        
        # Save the full text for manual analysis
        with open('data/raw/phase1_full_text.txt', 'w', encoding='utf-8') as f:
            f.write(all_text)
        
        # Look for gym-related keywords
        gym_keywords = ['gym', 'fitness', 'health club', 'wellness', 'workout']
        lines = all_text.split('\n')
        
        for line in lines:
            line = line.strip()
            if any(keyword.lower() in line.lower() for keyword in gym_keywords):
                if len(line) > 5 and len(line) < 100:  # Reasonable length for a business name
                    self.results.append({
                        'business_name': line,
                        'rating': None,
                        'address': None,
                        'extraction_method': 'keyword_fallback'
                    })
    
    def save_results(self, filename='data/processed/phase1_results.csv'):
        """
        Save extracted results to CSV
        """
        if self.results:
            df = pd.DataFrame(self.results)
            df.to_csv(filename, index=False, encoding='utf-8')
            logger.info(f"Results saved to {filename}")
            logger.info(f"Total records: {len(df)}")
            return df
        else:
            logger.warning("No results to save")
            return pd.DataFrame()
    
    def analyze_response(self):
        """
        Analyze the response to understand why extraction might have failed
        """
        logger.info("\n=== PHASE 1 ANALYSIS ===")
        logger.info("This phase demonstrates why basic scraping fails with modern websites:")
        logger.info("1. JavaScript-rendered content is not accessible to requests")
        logger.info("2. Anti-bot measures may redirect or block requests")
        logger.info("3. Dynamic content loading requires browser automation")
        
        if len(self.results) == 0:
            logger.info("\nResult: No business data extracted (Expected)")
            logger.info("Recommendation: Move to Phase 2 (Selenium-based scraping)")
        else:
            logger.info(f"\nSurprising result: {len(self.results)} businesses found!")
            logger.info("This suggests either:")
            logger.info("- Some content is server-side rendered")
            logger.info("- Fallback extraction found relevant text")

def main():
    """
    Main function to run Phase 1 scraping
    """
    logger.info("Starting Phase 1: Basic Web Scraping")
    logger.info("=" * 50)
    
    scraper = BasicJustdialScraper()
    
    # Attempt to scrape gym data
    success = scraper.search_gyms(city="Pune", search_term="Gyms")
    
    if success:
        # Save results
        df = scraper.save_results()
        
        # Analyze what we found
        scraper.analyze_response()
        
        if not df.empty:
            print("\nSample Results:")
            print(df.head())
    else:
        logger.error("Phase 1 scraping failed completely")
    
    logger.info("\nPhase 1 complete. Proceeding to Phase 2 recommended.")

if __name__ == "__main__":
    main()