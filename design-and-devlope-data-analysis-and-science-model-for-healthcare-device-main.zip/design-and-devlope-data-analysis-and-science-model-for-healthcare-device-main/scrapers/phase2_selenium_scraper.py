"""
Phase 2: Selenium-Based Web Scraping

This script introduces browser automation using Selenium to handle JavaScript-rendered content.
It uses basic Selenium configuration and may encounter bot detection measures.

Expected Improvements: 
- Can handle JavaScript content
- May still face anti-bot challenges
- Possible version compatibility issues with ChromeDriver
"""

import time
import pandas as pd
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SeleniumJustdialScraper:
    def __init__(self):
        self.driver = None
        self.results = []
        self.base_url = "https://www.justdial.com"
        
    def setup_driver(self):
        """
        Initialize the Chrome WebDriver with basic configuration
        """
        try:
            logger.info("Setting up Chrome WebDriver...")
            
            # Configure Chrome options
            chrome_options = Options()
            chrome_options.add_argument("--start-maximized")
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            
            # Install and setup ChromeDriver
            service = Service(ChromeDriverManager().install())
            
            # Create the driver
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            self.driver.implicitly_wait(10)
            
            logger.info("WebDriver setup successful")
            return True
            
        except WebDriverException as e:
            logger.error(f"WebDriver setup failed: {e}")
            logger.error("This might be due to Chrome/ChromeDriver version mismatch")
            return False
        except Exception as e:
            logger.error(f"Unexpected error during driver setup: {e}")
            return False
    
    def search_gyms(self, city="Pune", search_term="Gyms"):
        """
        Search for gyms using Selenium browser automation
        """
        try:
            logger.info(f"Navigating to Justdial homepage...")
            
            # Go to the main page first
            self.driver.get(self.base_url)
            time.sleep(3)
            
            # Take screenshot for debugging
            self.driver.save_screenshot('data/raw/phase2_homepage.png')
            
            logger.info("Looking for search elements...")
            
            # Try to find and fill the search form
            success = self._perform_search(search_term, city)
            
            if success:
                # Wait for results to load
                time.sleep(5)
                
                # Save page source for analysis
                with open('data/raw/phase2_results_page.html', 'w', encoding='utf-8') as f:
                    f.write(self.driver.page_source)
                
                # Take screenshot of results
                self.driver.save_screenshot('data/raw/phase2_results.png')
                
                # Extract business data
                self._extract_business_listings()
                
                return True
            else:
                logger.error("Failed to perform search")
                return False
                
        except TimeoutException:
            logger.error("Page load timeout - website might be slow or blocking")
            return False
        except Exception as e:
            logger.error(f"Error during search: {e}")
            return False
    
    def _perform_search(self, search_term, city):
        """
        Attempt to find and use the search functionality
        """
        try:
            # Common search form selectors
            search_selectors = [
                "input[placeholder*='Search']",
                "input[name='what']",
                "input#srchbx",
                "input.search-box",
                ".search-input input"
            ]
            
            city_selectors = [
                "input[placeholder*='City']",
                "input[name='where']", 
                "input#citybx",
                "input.city-box",
                ".city-input input"
            ]
            
            # Try to find search input
            search_input = None
            for selector in search_selectors:
                try:
                    search_input = WebDriverWait(self.driver, 5).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                    )
                    logger.info(f"Found search input with selector: {selector}")
                    break
                except TimeoutException:
                    continue
            
            if not search_input:
                logger.error("Could not find search input field")
                return False
            
            # Try to find city input
            city_input = None
            for selector in city_selectors:
                try:
                    city_input = self.driver.find_element(By.CSS_SELECTOR, selector)
                    logger.info(f"Found city input with selector: {selector}")
                    break
                except NoSuchElementException:
                    continue
            
            # Fill in the search form
            search_input.clear()
            search_input.send_keys(search_term)
            time.sleep(1)
            
            if city_input:
                city_input.clear()
                city_input.send_keys(city)
                time.sleep(1)
            
            # Try to find and click search button
            search_button_selectors = [
                "button[type='submit']",
                "input[type='submit']",
                ".search-button",
                ".search-btn",
                "button.btn-search"
            ]
            
            search_button = None
            for selector in search_button_selectors:
                try:
                    search_button = self.driver.find_element(By.CSS_SELECTOR, selector)
                    break
                except NoSuchElementException:
                    continue
            
            if search_button:
                logger.info("Clicking search button...")
                search_button.click()
            else:
                # Try pressing Enter on search input
                logger.info("No search button found, trying Enter key...")
                from selenium.webdriver.common.keys import Keys
                search_input.send_keys(Keys.RETURN)
            
            return True
            
        except Exception as e:
            logger.error(f"Error performing search: {e}")
            return False
    
    def _extract_business_listings(self):
        """
        Extract business information from the loaded results page
        """
        logger.info("Extracting business listings...")
        
        # Parse the page source with BeautifulSoup
        soup = BeautifulSoup(self.driver.page_source, 'html.parser')
        
        # Look for business listing containers
        listing_selectors = [
            '.result-box',
            '.srp-tuple', 
            '.listing-card',
            '.business-item',
            '.store-details',
            '[data-business]'
        ]
        
        businesses_found = 0
        
        for selector in listing_selectors:
            elements = soup.select(selector)
            if elements:
                logger.info(f"Found {len(elements)} potential listings with selector: {selector}")
                
                for element in elements:
                    business_data = self._parse_business_element(element)
                    if business_data:
                        self.results.append(business_data)
                        businesses_found += 1
                
                if businesses_found > 0:
                    break  # Stop if we found businesses with this selector
        
        # If no structured data found, try alternative extraction
        if businesses_found == 0:
            self._alternative_extraction(soup)
        
        logger.info(f"Total businesses extracted: {len(self.results)}")
    
    def _parse_business_element(self, element):
        """
        Extract business details from a single listing element
        """
        try:
            # Extract business name
            name_selectors = ['h3', 'h4', '.business-name', '.store-name', 'a[title]', '.comp-text']
            business_name = None
            
            for selector in name_selectors:
                name_elem = element.select_one(selector)
                if name_elem:
                    business_name = name_elem.get_text(strip=True)
                    if business_name and len(business_name) > 2:
                        break
            
            # Extract rating
            rating_selectors = ['.rating', '.star', '[data-rating]', '.review-score']
            rating = None
            
            for selector in rating_selectors:
                rating_elem = element.select_one(selector)
                if rating_elem:
                    rating_text = rating_elem.get_text(strip=True)
                    # Extract numeric rating
                    import re
                    rating_match = re.search(r'(\d+\.?\d*)', rating_text)
                    if rating_match:
                        try:
                            rating = float(rating_match.group(1))
                            if rating <= 5:  # Valid rating range
                                break
                        except ValueError:
                            continue
            
            # Extract address
            address_selectors = ['.address', '.location', '.addr', '.locality']
            address = None
            
            for selector in address_selectors:
                addr_elem = element.select_one(selector)
                if addr_elem:
                    address = addr_elem.get_text(strip=True)
                    if address and len(address) > 5:
                        break
            
            # Extract phone (bonus data)
            phone_selectors = ['.phone', '.mobile', '.contact', '[href^="tel:"]']
            phone = None
            
            for selector in phone_selectors:
                phone_elem = element.select_one(selector)
                if phone_elem:
                    phone = phone_elem.get_text(strip=True)
                    if phone and len(phone) > 5:
                        break
            
            if business_name:
                return {
                    'business_name': business_name,
                    'rating': rating,
                    'address': address,
                    'phone': phone,
                    'extraction_method': 'selenium_structured',
                    'source_phase': 'phase2'
                }
                
        except Exception as e:
            logger.debug(f"Error parsing business element: {e}")
        
        return None
    
    def _alternative_extraction(self, soup):
        """
        Alternative extraction method if structured data fails
        """
        logger.info("Attempting alternative extraction...")
        
        # Look for any clickable links or elements that might be businesses
        links = soup.find_all('a', href=True)
        
        gym_keywords = ['gym', 'fitness', 'health', 'wellness', 'club', 'center']
        
        for link in links:
            text = link.get_text(strip=True)
            if text and any(keyword.lower() in text.lower() for keyword in gym_keywords):
                if 5 < len(text) < 100:  # Reasonable business name length
                    self.results.append({
                        'business_name': text,
                        'rating': None,
                        'address': None,
                        'phone': None,
                        'extraction_method': 'selenium_alternative',
                        'source_phase': 'phase2'
                    })
    
    def save_results(self, filename='data/processed/phase2_results.csv'):
        """
        Save extracted results to CSV
        """
        if self.results:
            df = pd.DataFrame(self.results)
            # Remove duplicates
            df = df.drop_duplicates(subset=['business_name'])
            df.to_csv(filename, index=False, encoding='utf-8')
            logger.info(f"Results saved to {filename}")
            logger.info(f"Total unique records: {len(df)}")
            return df
        else:
            logger.warning("No results to save")
            return pd.DataFrame()
    
    def analyze_phase2_results(self):
        """
        Analyze Phase 2 results and provide insights
        """
        logger.info("\n=== PHASE 2 ANALYSIS ===")
        logger.info("Selenium-based scraping allows handling of:")
        logger.info("1. JavaScript-rendered content")
        logger.info("2. Dynamic page interactions")
        logger.info("3. Complex form submissions")
        
        if len(self.results) == 0:
            logger.info("\nResult: Limited success (Expected)")
            logger.info("Possible reasons:")
            logger.info("- Website detected automation")
            logger.info("- Content structure changed")
            logger.info("- Anti-bot measures triggered")
            logger.info("Recommendation: Move to Phase 3 (Anti-detection measures)")
        else:
            logger.info(f"\nSuccess: {len(self.results)} businesses extracted!")
            logger.info("Phase 2 successfully bypassed basic JavaScript challenges")
    
    def cleanup(self):
        """
        Clean up resources
        """
        if self.driver:
            self.driver.quit()
            logger.info("WebDriver closed")

def main():
    """
    Main function to run Phase 2 scraping
    """
    logger.info("Starting Phase 2: Selenium-Based Web Scraping")
    logger.info("=" * 50)
    
    scraper = SeleniumJustdialScraper()
    
    try:
        # Setup WebDriver
        if not scraper.setup_driver():
            logger.error("Failed to setup WebDriver. Cannot proceed.")
            return
        
        # Perform scraping
        success = scraper.search_gyms(city="Pune", search_term="Gyms")
        
        if success:
            # Save results
            df = scraper.save_results()
            
            # Analyze results
            scraper.analyze_phase2_results()
            
            if not df.empty:
                print("\nSample Results:")
                print(df.head())
                print(f"\nColumns available: {list(df.columns)}")
        else:
            logger.error("Phase 2 scraping encountered issues")
        
    except Exception as e:
        logger.error(f"Unexpected error in Phase 2: {e}")
    
    finally:
        # Always cleanup
        scraper.cleanup()
    
    logger.info("\nPhase 2 complete. If results are limited, proceed to Phase 3.")

if __name__ == "__main__":
    main()