"""
Phase 3: Advanced Selenium with Anti-Detection Measures

This script implements sophisticated techniques to bypass bot detection:
- Chrome profile usage for session persistence
- Advanced Chrome options to hide automation
- Human-like behavior simulation
- Improved error handling and retry mechanisms

Expected Improvements:
- Better success rate against anti-bot measures
- Session persistence through Chrome profiles
- More natural browsing patterns
"""

import time
import random
import pandas as pd
import logging
import os
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
from fake_useragent import UserAgent

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AdvancedJustdialScraper:
    def __init__(self):
        self.driver = None
        self.results = []
        self.base_url = "https://www.justdial.com"
        self.profile_path = None
        self.ua = UserAgent()
        
    def setup_driver(self, use_profile=True):
        """
        Initialize Chrome WebDriver with advanced anti-detection measures
        """
        try:
            logger.info("Setting up advanced Chrome WebDriver...")
            
            # Configure Chrome options with anti-detection measures
            chrome_options = Options()
            
            # Basic window and display settings
            chrome_options.add_argument("--start-maximized")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            
            # Anti-detection measures
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            chrome_options.add_argument("--disable-extensions")
            chrome_options.add_argument("--disable-plugins")
            chrome_options.add_argument("--disable-images")  # Faster loading
            chrome_options.add_argument("--disable-javascript")  # May need to remove this
            
            # Disable notifications and popups
            prefs = {
                "profile.default_content_setting_values.notifications": 2,
                "profile.default_content_settings.popups": 0,
                "profile.managed_default_content_settings.images": 2,
                "profile.default_content_setting_values.media_stream": 2,
            }
            chrome_options.add_experimental_option("prefs", prefs)
            
            # Use a persistent Chrome profile
            if use_profile:
                self.profile_path = self._setup_chrome_profile()
                if self.profile_path:
                    chrome_options.add_argument(f"--user-data-dir={self.profile_path}")
                    logger.info(f"Using Chrome profile: {self.profile_path}")
            
            # Set a realistic user agent
            user_agent = self.ua.random
            chrome_options.add_argument(f"--user-agent={user_agent}")
            logger.info(f"Using User-Agent: {user_agent}")
            
            # Install and setup ChromeDriver
            service = Service(ChromeDriverManager().install())
            
            # Create the driver
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            
            # Execute script to further hide automation
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            
            self.driver.implicitly_wait(10)
            
            logger.info("Advanced WebDriver setup successful")
            return True
            
        except WebDriverException as e:
            logger.error(f"Advanced WebDriver setup failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error during advanced driver setup: {e}")
            return False
    
    def _setup_chrome_profile(self):
        """
        Setup a persistent Chrome profile for session continuity
        """
        try:
            profile_dir = Path("config/chrome_profile")
            profile_dir.mkdir(parents=True, exist_ok=True)
            return str(profile_dir.absolute())
        except Exception as e:
            logger.warning(f"Failed to setup Chrome profile: {e}")
            return None
    
    def human_like_delay(self, min_delay=1, max_delay=3):
        """
        Add human-like delays between actions
        """
        delay = random.uniform(min_delay, max_delay)
        time.sleep(delay)
    
    def simulate_human_behavior(self):
        """
        Simulate human browsing behavior
        """
        try:
            # Random mouse movements
            actions = ActionChains(self.driver)
            
            # Get window size
            window_size = self.driver.get_window_size()
            width = window_size['width']
            height = window_size['height']
            
            # Random mouse movements
            for _ in range(random.randint(2, 5)):
                x = random.randint(0, width)
                y = random.randint(0, height)
                actions.move_by_offset(x - width//2, y - height//2)
                actions.perform()
                time.sleep(random.uniform(0.1, 0.5))
            
            # Random scrolling
            for _ in range(random.randint(1, 3)):
                self.driver.execute_script(f"window.scrollBy(0, {random.randint(-200, 200)})")
                time.sleep(random.uniform(0.2, 0.8))
                
        except Exception as e:
            logger.debug(f"Error in human behavior simulation: {e}")
    
    def search_gyms(self, city="Pune", search_term="Gyms"):
        """
        Search for gyms using advanced techniques with retry mechanism
        """
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                logger.info(f"Attempt {attempt + 1}/{max_retries} - Navigating to Justdial...")
                
                # Navigate to homepage first
                self.driver.get(self.base_url)
                self.human_like_delay(2, 4)
                
                # Simulate human behavior
                self.simulate_human_behavior()
                
                # Take screenshot for debugging
                self.driver.save_screenshot(f'data/raw/phase3_homepage_attempt_{attempt + 1}.png')
                
                # Check if we're redirected or blocked
                current_url = self.driver.current_url
                if "justdial.com" not in current_url:
                    logger.warning(f"Redirected to: {current_url}")
                    if attempt < max_retries - 1:
                        continue
                    else:
                        return False
                
                # Try to perform search
                success = self._perform_advanced_search(search_term, city)
                
                if success:
                    # Wait for results with multiple checks
                    self._wait_for_results()
                    
                    # Save page source
                    with open(f'data/raw/phase3_results_attempt_{attempt + 1}.html', 'w', encoding='utf-8') as f:
                        f.write(self.driver.page_source)
                    
                    # Take screenshot of results
                    self.driver.save_screenshot(f'data/raw/phase3_results_attempt_{attempt + 1}.png')
                    
                    # Extract business data
                    self._extract_business_listings()
                    
                    if len(self.results) > 0:
                        logger.info(f"Success on attempt {attempt + 1}")
                        return True
                    else:
                        logger.warning(f"No results found on attempt {attempt + 1}")
                
                # If we reach here, this attempt failed
                if attempt < max_retries - 1:
                    logger.info(f"Attempt {attempt + 1} failed, retrying...")
                    self.human_like_delay(5, 10)  # Longer delay between retries
                
            except TimeoutException:
                logger.error(f"Timeout on attempt {attempt + 1}")
                if attempt < max_retries - 1:
                    continue
            except Exception as e:
                logger.error(f"Error on attempt {attempt + 1}: {e}")
                if attempt < max_retries - 1:
                    continue
        
        logger.error("All attempts failed")
        return False
    
    def _perform_advanced_search(self, search_term, city):
        """
        Perform search with advanced interaction patterns
        """
        try:
            logger.info("Looking for search elements with advanced techniques...")
            
            # Wait for page to fully load
            WebDriverWait(self.driver, 15).until(
                lambda driver: driver.execute_script("return document.readyState") == "complete"
            )
            
            # Multiple strategies to find search elements
            search_strategies = [
                self._search_strategy_1,
                self._search_strategy_2,
                self._search_strategy_3
            ]
            
            for i, strategy in enumerate(search_strategies):
                logger.info(f"Trying search strategy {i + 1}...")
                if strategy(search_term, city):
                    logger.info(f"Search strategy {i + 1} successful")
                    return True
                
                self.human_like_delay(1, 2)
            
            logger.error("All search strategies failed")
            return False
            
        except Exception as e:
            logger.error(f"Error in advanced search: {e}")
            return False
    
    def _search_strategy_1(self, search_term, city):
        """
        Strategy 1: Standard form-based search
        """
        try:
            # Look for search input
            search_selectors = [
                "input[placeholder*='Search']",
                "input[name='what']",
                "#srchbx",
                ".search-input input",
                "input[type='search']"
            ]
            
            search_input = None
            for selector in search_selectors:
                try:
                    search_input = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    break
                except TimeoutException:
                    continue
            
            if not search_input:
                return False
            
            # Human-like typing
            search_input.click()
            self.human_like_delay(0.5, 1)
            search_input.clear()
            
            # Type with human-like delays
            for char in search_term:
                search_input.send_keys(char)
                time.sleep(random.uniform(0.05, 0.15))
            
            self.human_like_delay(1, 2)
            
            # Try to find and fill city
            city_selectors = [
                "input[placeholder*='City']",
                "input[name='where']",
                "#citybx",
                ".city-input input"
            ]
            
            for selector in city_selectors:
                try:
                    city_input = self.driver.find_element(By.CSS_SELECTOR, selector)
                    city_input.click()
                    self.human_like_delay(0.5, 1)
                    city_input.clear()
                    
                    for char in city:
                        city_input.send_keys(char)
                        time.sleep(random.uniform(0.05, 0.15))
                    
                    break
                except NoSuchElementException:
                    continue
            
            # Submit search
            search_input.send_keys(Keys.RETURN)
            return True
            
        except Exception as e:
            logger.debug(f"Search strategy 1 failed: {e}")
            return False
    
    def _search_strategy_2(self, search_term, city):
        """
        Strategy 2: Direct URL navigation
        """
        try:
            # Construct search URL
            search_url = f"{self.base_url}/{city.lower()}/{search_term.lower().replace(' ', '-')}"
            logger.info(f"Trying direct URL: {search_url}")
            
            self.driver.get(search_url)
            self.human_like_delay(3, 5)
            
            # Check if we got results page
            if "search" in self.driver.current_url.lower() or "list" in self.driver.current_url.lower():
                return True
            
            return False
            
        except Exception as e:
            logger.debug(f"Search strategy 2 failed: {e}")
            return False
    
    def _search_strategy_3(self, search_term, city):
        """
        Strategy 3: JavaScript-based search
        """
        try:
            # Use JavaScript to trigger search
            script = f"""
            var searchTerm = '{search_term}';
            var city = '{city}';
            
            // Try to find and fill search inputs
            var searchInputs = document.querySelectorAll('input[type="text"], input[type="search"]');
            for (var i = 0; i < searchInputs.length; i++) {{
                if (searchInputs[i].placeholder && 
                    (searchInputs[i].placeholder.toLowerCase().includes('search') ||
                     searchInputs[i].placeholder.toLowerCase().includes('what'))) {{
                    searchInputs[i].value = searchTerm;
                    searchInputs[i].dispatchEvent(new Event('input'));
                }}
                if (searchInputs[i].placeholder && 
                    (searchInputs[i].placeholder.toLowerCase().includes('city') ||
                     searchInputs[i].placeholder.toLowerCase().includes('where'))) {{
                    searchInputs[i].value = city;
                    searchInputs[i].dispatchEvent(new Event('input'));
                }}
            }}
            
            // Try to submit
            var forms = document.querySelectorAll('form');
            if (forms.length > 0) {{
                forms[0].submit();
                return true;
            }}
            return false;
            """
            
            result = self.driver.execute_script(script)
            if result:
                self.human_like_delay(3, 5)
                return True
            
            return False
            
        except Exception as e:
            logger.debug(f"Search strategy 3 failed: {e}")
            return False
    
    def _wait_for_results(self):
        """
        Wait for search results to load with multiple indicators
        """
        try:
            # Wait for any of these indicators
            wait_conditions = [
                EC.presence_of_element_located((By.CSS_SELECTOR, ".result-box")),
                EC.presence_of_element_located((By.CSS_SELECTOR, ".srp-tuple")),
                EC.presence_of_element_located((By.CSS_SELECTOR, ".listing-card")),
                EC.presence_of_element_located((By.CSS_SELECTOR, "[data-business]"))
            ]
            
            for condition in wait_conditions:
                try:
                    WebDriverWait(self.driver, 10).until(condition)
                    logger.info("Results loaded successfully")
                    return True
                except TimeoutException:
                    continue
            
            # If no specific elements found, wait for page stability
            WebDriverWait(self.driver, 15).until(
                lambda driver: driver.execute_script("return document.readyState") == "complete"
            )
            
            logger.info("Page loaded, proceeding with extraction")
            return True
            
        except Exception as e:
            logger.warning(f"Error waiting for results: {e}")
            return False
    
    def _extract_business_listings(self):
        """
        Extract business information with improved parsing
        """
        logger.info("Extracting business listings with advanced parsing...")
        
        # Parse the page source
        soup = BeautifulSoup(self.driver.page_source, 'html.parser')
        
        # Comprehensive list of possible listing selectors
        listing_selectors = [
            '.result-box',
            '.srp-tuple',
            '.listing-card',
            '.business-item',
            '.store-details',
            '.comp-text',
            '[data-business]',
            '.list-store',
            '.resultbox'
        ]
        
        businesses_found = 0
        
        for selector in listing_selectors:
            elements = soup.select(selector)
            if elements:
                logger.info(f"Found {len(elements)} potential listings with selector: {selector}")
                
                for element in elements[:20]:  # Process up to 20 elements
                    business_data = self._parse_business_element_advanced(element)
                    if business_data:
                        self.results.append(business_data)
                        businesses_found += 1
                
                if businesses_found > 0:
                    break  # Use the first successful selector
        
        # Enhanced fallback extraction
        if businesses_found == 0:
            self._enhanced_fallback_extraction(soup)
        
        logger.info(f"Total businesses extracted: {len(self.results)}")
    
    def _parse_business_element_advanced(self, element):
        """
        Advanced business data extraction with multiple fallback strategies
        """
        try:
            business_data = {
                'business_name': None,
                'rating': None,
                'address': None,
                'phone': None,
                'extraction_method': 'phase3_advanced',
                'source_phase': 'phase3'
            }
            
            # Extract business name with multiple strategies
            name_strategies = [
                lambda e: e.select_one('h3, h4, h5'),
                lambda e: e.select_one('.business-name, .store-name, .comp-text'),
                lambda e: e.select_one('a[title]'),
                lambda e: e.select_one('.jcn a'),
                lambda e: e.select_one('strong')
            ]
            
            for strategy in name_strategies:
                try:
                    name_elem = strategy(element)
                    if name_elem:
                        name = name_elem.get_text(strip=True)
                        if name and 2 < len(name) < 100:
                            business_data['business_name'] = name
                            break
                except:
                    continue
            
            # Extract rating with multiple patterns
            rating_patterns = [
                r'(\d+\.?\d*)\s*(?:star|★|rating)',
                r'rating[:\s]*(\d+\.?\d*)',
                r'(\d+\.?\d*)\s*/\s*5'
            ]
            
            element_text = element.get_text()
            for pattern in rating_patterns:
                import re
                match = re.search(pattern, element_text, re.IGNORECASE)
                if match:
                    try:
                        rating = float(match.group(1))
                        if 0 <= rating <= 5:
                            business_data['rating'] = rating
                            break
                    except ValueError:
                        continue
            
            # Extract address with improved detection
            address_selectors = [
                '.address, .location, .addr, .locality',
                '.cont-fl-addr',
                '.mrehover',
                'span:contains("Address")',
                '.store-address'
            ]
            
            for selector in address_selectors:
                try:
                    addr_elem = element.select_one(selector)
                    if addr_elem:
                        address = addr_elem.get_text(strip=True)
                        if address and 10 < len(address) < 200:
                            business_data['address'] = address
                            break
                except:
                    continue
            
            # Extract phone number
            phone_patterns = [
                r'(\+?91[\s-]?\d{10})',
                r'(\d{10})',
                r'(\d{5}[\s-]\d{5})',
                r'(\d{4}[\s-]\d{3}[\s-]\d{3})'
            ]
            
            for pattern in phone_patterns:
                import re
                match = re.search(pattern, element_text)
                if match:
                    business_data['phone'] = match.group(1)
                    break
            
            # Return data if we have at least a business name
            if business_data['business_name']:
                return business_data
                
        except Exception as e:
            logger.debug(f"Error in advanced parsing: {e}")
        
        return None
    
    def _enhanced_fallback_extraction(self, soup):
        """
        Enhanced fallback extraction when structured parsing fails
        """
        logger.info("Attempting enhanced fallback extraction...")
        
        # Look for any text that might contain business information
        text_content = soup.get_text()
        
        # Save full text for manual analysis
        with open('data/raw/phase3_full_text.txt', 'w', encoding='utf-8') as f:
            f.write(text_content)
        
        # Look for gym-related patterns in text
        gym_patterns = [
            r'([A-Z][a-zA-Z\s]+(?:Gym|Fitness|Health|Club|Center)[a-zA-Z\s]*)',
            r'([A-Z][a-zA-Z\s]{5,50})\s+(?:Gym|Fitness)',
            r'(Gold\'s\s+Gym|Anytime\s+Fitness|Planet\s+Fitness|[A-Z][a-zA-Z\s]+\s+Fitness)'
        ]
        
        import re
        for pattern in gym_patterns:
            matches = re.findall(pattern, text_content, re.IGNORECASE)
            for match in matches[:10]:  # Limit to 10 matches per pattern
                business_name = match.strip() if isinstance(match, str) else match[0].strip()
                if 5 < len(business_name) < 80:
                    self.results.append({
                        'business_name': business_name,
                        'rating': None,
                        'address': None,
                        'phone': None,
                        'extraction_method': 'phase3_fallback',
                        'source_phase': 'phase3'
                    })
    
    def save_results(self, filename='data/processed/phase3_results.csv'):
        """
        Save results with enhanced data cleaning
        """
        if self.results:
            df = pd.DataFrame(self.results)
            
            # Enhanced data cleaning
            df = df.drop_duplicates(subset=['business_name'])
            df['business_name'] = df['business_name'].str.strip()
            df = df[df['business_name'].str.len() > 2]  # Remove very short names
            
            df.to_csv(filename, index=False, encoding='utf-8')
            logger.info(f"Results saved to {filename}")
            logger.info(f"Total unique records: {len(df)}")
            
            # Save detailed statistics
            stats = {
                'total_records': len(df),
                'records_with_rating': df['rating'].notna().sum(),
                'records_with_address': df['address'].notna().sum(),
                'records_with_phone': df['phone'].notna().sum(),
                'extraction_methods': df['extraction_method'].value_counts().to_dict()
            }
            
            logger.info(f"Extraction statistics: {stats}")
            return df
        else:
            logger.warning("No results to save")
            return pd.DataFrame()
    
    def analyze_phase3_results(self):
        """
        Analyze Phase 3 results and provide insights
        """
        logger.info("\n=== PHASE 3 ANALYSIS ===")
        logger.info("Advanced anti-detection measures implemented:")
        logger.info("1. Chrome profile for session persistence")
        logger.info("2. Human behavior simulation")
        logger.info("3. Multiple search strategies")
        logger.info("4. Advanced parsing techniques")
        logger.info("5. Retry mechanisms")
        
        if len(self.results) == 0:
            logger.info("\nResult: Still facing challenges")
            logger.info("Website may have very sophisticated anti-bot measures")
            logger.info("Recommendation: Move to Phase 4 (Selenium-Stealth)")
        else:
            logger.info(f"\nGood progress: {len(self.results)} businesses extracted!")
            logger.info("Phase 3 anti-detection measures showing success")
    
    def cleanup(self):
        """
        Clean up resources
        """
        if self.driver:
            self.driver.quit()
            logger.info("Advanced WebDriver closed")

def main():
    """
    Main function to run Phase 3 scraping
    """
    logger.info("Starting Phase 3: Advanced Anti-Detection Web Scraping")
    logger.info("=" * 60)
    
    scraper = AdvancedJustdialScraper()
    
    try:
        # Setup advanced WebDriver
        if not scraper.setup_driver(use_profile=True):
            logger.error("Failed to setup advanced WebDriver. Cannot proceed.")
            return
        
        # Perform advanced scraping
        success = scraper.search_gyms(city="Pune", search_term="Gyms")
        
        if success:
            # Save results
            df = scraper.save_results()
            
            # Analyze results
            scraper.analyze_phase3_results()
            
            if not df.empty:
                print("\nSample Results:")
                print(df.head())
                print(f"\nData quality metrics:")
                print(f"- Records with ratings: {df['rating'].notna().sum()}/{len(df)}")
                print(f"- Records with addresses: {df['address'].notna().sum()}/{len(df)}")
        else:
            logger.error("Phase 3 scraping still encountering issues")
        
    except Exception as e:
        logger.error(f"Unexpected error in Phase 3: {e}")
    
    finally:
        # Always cleanup
        scraper.cleanup()
    
    logger.info("\nPhase 3 complete. For maximum success rate, proceed to Phase 4.")

if __name__ == "__main__":
    main()