"""
Phase 4: Ultimate Selenium-Stealth Solution

This script implements the most advanced web scraping techniques using selenium-stealth
to make the browser virtually undetectable. This is the production-ready solution
that should successfully bypass even the most sophisticated anti-bot measures.
"""

import time
import random
import pandas as pd
import logging
import os
import json
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import undetected_chromedriver as uc
from selenium_stealth import stealth
from bs4 import BeautifulSoup
import re

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class StealthJustdialScraper:
    def __init__(self):
        self.driver = None
        self.results = []
        self.base_url = "https://www.justdial.com"
        
    def setup_stealth_driver(self):
        """Initialize the ultimate stealth WebDriver configuration"""
        try:
            logger.info("Setting up ultimate stealth WebDriver...")
            
            options = uc.ChromeOptions()
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument("--disable-blink-features=AutomationControlled")
            
            self.driver = uc.Chrome(options=options)
            
            stealth(self.driver,
                   languages=["en-US", "en"],
                   vendor="Google Inc.",
                   platform="Win32",
                   webgl_vendor="Intel Inc.",
                   renderer="Intel Iris OpenGL Engine",
                   fix_hairline=True)
            
            self.driver.execute_script("""
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                window.chrome = {runtime: {}};
            """)
            
            logger.info("Ultimate stealth WebDriver setup successful")
            return True
            
        except Exception as e:
            logger.error(f"Stealth WebDriver setup failed: {e}")
            return False
    
    def search_gyms_ultimate(self, city="Pune", search_term="Gyms"):
        """Ultimate gym search with maximum success probability"""
        try:
            logger.info("Starting ultimate search strategy...")
            
            # Navigate to homepage
            self.driver.get(self.base_url)
            time.sleep(random.uniform(3, 5))
            
            # Simulate human behavior
            self._simulate_human_behavior()
            
            # Try comprehensive search
            if self._perform_comprehensive_search(search_term, city):
                self._extract_comprehensive_results()
                return len(self.results) > 0
            
            return False
            
        except Exception as e:
            logger.error(f"Ultimate search failed: {e}")
            return False
    
    def _simulate_human_behavior(self):
        """Simulate realistic human browsing"""
        try:
            # Set realistic window size
            self.driver.set_window_size(1920, 1080)
            
            # Random scrolling and movements
            for _ in range(random.randint(2, 4)):
                self.driver.execute_script(f"window.scrollBy(0, {random.randint(-200, 200)})")
                time.sleep(random.uniform(0.5, 1.5))
                
        except Exception as e:
            logger.debug(f"Error in behavior simulation: {e}")
    
    def _perform_comprehensive_search(self, search_term, city):
        """Comprehensive search with multiple fallbacks"""
        try:
            # Strategy 1: Main search form
            if self._try_main_search(search_term, city):
                return True
            
            # Strategy 2: Direct URL
            direct_urls = [
                f"{self.base_url}/{city.lower()}/{search_term.lower()}",
                f"{self.base_url}/search/{city.lower()}/{search_term.lower()}"
            ]
            
            for url in direct_urls:
                try:
                    self.driver.get(url)
                    time.sleep(3)
                    if "gym" in self.driver.page_source.lower():
                        return True
                except:
                    continue
            
            return False
            
        except Exception as e:
            logger.error(f"Comprehensive search failed: {e}")
            return False
    
    def _try_main_search(self, search_term, city):
        """Try main search form"""
        try:
            # Find search input
            search_selectors = [
                "input[placeholder*='Search']",
                "input[name='what']",
                "#srchbx",
                ".search-input input"
            ]
            
            search_input = None
            for selector in search_selectors:
                try:
                    search_input = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    break
                except TimeoutException:
                    continue
            
            if not search_input:
                return False
            
            # Human-like typing
            search_input.click()
            time.sleep(0.5)
            search_input.clear()
            
            for char in search_term:
                search_input.send_keys(char)
                time.sleep(random.uniform(0.08, 0.15))
            
            search_input.send_keys(Keys.RETURN)
            time.sleep(3)
            
            return True
            
        except Exception as e:
            logger.debug(f"Main search failed: {e}")
            return False
    
    def _extract_comprehensive_results(self):
        """Extract results with comprehensive methods"""
        logger.info("Extracting results comprehensively...")
        
        # Save page for analysis
        with open('data/raw/phase4_results.html', 'w', encoding='utf-8') as f:
            f.write(self.driver.page_source)
        
        soup = BeautifulSoup(self.driver.page_source, 'html.parser')
        
        # Method 1: Structured extraction
        self._extract_structured(soup)
        
        # Method 2: Pattern-based extraction
        self._extract_patterns(soup)
        
        # Clean duplicates
        self._clean_results()
        
        logger.info(f"Extraction complete: {len(self.results)} businesses found")
    
    def _extract_structured(self, soup):
        """Extract from structured elements"""
        selectors = [
            '.result-box', '.srp-tuple', '.listing-card', 
            '.business-item', '.comp-text'
        ]
        
        for selector in selectors:
            elements = soup.select(selector)
            if elements:
                logger.info(f"Processing {len(elements)} elements with {selector}")
                
                for element in elements[:30]:
                    business_data = self._parse_business_element(element)
                    if business_data:
                        self.results.append(business_data)
    
    def _parse_business_element(self, element):
        """Parse individual business element"""
        try:
            # Extract name
            name_elem = (element.select_one('h3, h4, .business-name, .store-name') or
                        element.select_one('a[title]') or
                        element.select_one('strong'))
            
            if not name_elem:
                return None
            
            business_name = name_elem.get_text(strip=True)
            if not business_name or len(business_name) < 3:
                return None
            
            rating = None
            # Find the new class for the rating, for example: '.rating-number'
            rating_elem = element.select_one('.rating-number') 
            if rating_elem:
                try:
                    # Your logic to extract rating number
                    rating = float(rating_elem.get_text(strip=True))
                except ValueError:
                    rating = None
            
            # Extract address
            address = None
            # Find the new class for the address, for example: '.location-info'
            addr_elem = element.select_one('.location-info')
            if addr_elem:
                address = addr_elem.get_text(strip=True)
            
            # Extract phone
            phone = None
            phone_match = re.search(r'(\d{10})', element_text)
            if phone_match:
                phone = phone_match.group(1)
            
            return {
                'business_name': business_name,
                'rating': rating,
                'address': address,
                'phone': phone,
                'extraction_method': 'phase4_structured'
            }
            
        except Exception as e:
            logger.debug(f"Error parsing element: {e}")
            return None
    
    def _extract_patterns(self, soup):
        """Extract using pattern recognition"""
        text = soup.get_text()
        
        # Gym name patterns
        patterns = [
            r'([A-Z][a-zA-Z\s]+(?:Gym|Fitness|Health Club)[a-zA-Z\s]*)',
            r'(Gold\'s\s+Gym|Anytime\s+Fitness|Planet\s+Fitness)'
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches[:15]:
                name = match.strip() if isinstance(match, str) else match[0].strip()
                if 5 <= len(name) <= 60:
                    self.results.append({
                        'business_name': name,
                        'rating': None,
                        'address': None,
                        'phone': None,
                        'extraction_method': 'phase4_pattern'
                    })
    
    def _clean_results(self):
        """Clean and deduplicate results"""
        if not self.results:
            return
        
        # Convert to DataFrame for easier cleaning
        df = pd.DataFrame(self.results)
        
        # Remove duplicates
        df = df.drop_duplicates(subset=['business_name'])
        
        # Clean business names
        df['business_name'] = df['business_name'].str.strip()
        df = df[df['business_name'].str.len() > 2]
        
        self.results = df.to_dict('records')
    
    def save_results(self, filename='data/processed/phase4_ultimate_results.csv'):
        """Save results with comprehensive metadata"""
        if self.results:
            df = pd.DataFrame(self.results)
            df.to_csv(filename, index=False, encoding='utf-8')
            
            logger.info(f"Results saved to {filename}")
            logger.info(f"Total records: {len(df)}")
            
            # Save statistics
           # Save statistics
            stats ={
               'total_records': len(df),
               'records_with_rating': int(df['rating'].notna().sum()),
               'records_with_address': int(df['address'].notna().sum()),
               'records_with_phone': int(df['phone'].notna().sum())
        }
            
            with open('data/output/phase4_statistics.json', 'w') as f:
                json.dump(stats, f, indent=2)
            
            return df
        else:
            logger.warning("No results to save")
            return pd.DataFrame()
    
    def cleanup(self):
        """Clean up resources"""
        if self.driver:
            self.driver.quit()
            logger.info("Stealth WebDriver closed")

def main():
    """Main function to run Phase 4 ultimate scraping"""
    logger.info("Starting Phase 4: Ultimate Stealth Web Scraping")
    logger.info("=" * 50)
    
    scraper = StealthJustdialScraper()
    
    try:
        if not scraper.setup_stealth_driver():
            logger.error("Failed to setup stealth WebDriver")
            return
        
        success = scraper.search_gyms_ultimate(city="Pune", search_term="Gyms")
        
        if success:
            df = scraper.save_results()
            
            if not df.empty:
                print("\nUltimate Results Summary:")
                print(f"Total businesses found: {len(df)}")
                print(f"Records with ratings: {df['rating'].notna().sum()}")
                print(f"Records with addresses: {df['address'].notna().sum()}")
                print("\nSample results:")
                print(df.head())
            else:
                logger.warning("No results extracted")
        else:
            logger.error("Ultimate scraping failed")
    
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
    
    finally:
        scraper.cleanup()

if __name__ == "__main__":
    main()