"""
Data Processing Module for Market Opportunity Analysis

This module handles data cleaning, validation, enrichment, and preparation
for market analysis of gym and fitness center data scraped from Justdial.
"""

import pandas as pd
import numpy as np
import re
import logging
from pathlib import Path
import json
from typing import Dict, List, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class FitnessDataProcessor:
    def __init__(self):
        self.data = None
        self.clean_data = None
        self.enriched_data = None
        self.validation_report = {}
        
    def load_scraped_data(self, file_path: str) -> pd.DataFrame:
        """Load data from CSV file with error handling"""
        try:
            if not Path(file_path).exists():
                logger.error(f"File not found: {file_path}")
                return pd.DataFrame()
            
            self.data = pd.read_csv(file_path, encoding='utf-8')
            logger.info(f"Loaded {len(self.data)} records from {file_path}")
            
            # Initial data overview
            self._log_data_overview()
            return self.data
            
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            return pd.DataFrame()
    
    def _log_data_overview(self):
        """Log basic data overview"""
        if self.data is not None:
            logger.info(f"Data shape: {self.data.shape}")
            logger.info(f"Columns: {list(self.data.columns)}")
            logger.info(f"Missing values per column: {self.data.isnull().sum().to_dict()}")
    
    def clean_business_names(self) -> pd.DataFrame:
        """Clean and standardize business names"""
        if self.data is None:
            logger.error("No data loaded")
            return pd.DataFrame()
        
        logger.info("Cleaning business names...")
        
        df = self.data.copy()
        
        # Basic cleaning
        df['business_name'] = df['business_name'].astype(str)
        df['business_name'] = df['business_name'].str.strip()
        
        # Remove extra whitespace
        df['business_name'] = df['business_name'].str.replace(r'\s+', ' ', regex=True)
        
        # Remove common unwanted prefixes/suffixes
        unwanted_patterns = [
            r'^(View|More|Contact|Call|Visit)\s+',
            r'\s+(View|More|Contact|Call|Visit)$',
            r'^\d+\.\s*',  # Remove numbering
            r'^-\s*',       # Remove leading dashes
        ]
        
        for pattern in unwanted_patterns:
            df['business_name'] = df['business_name'].str.replace(pattern, '', regex=True)
        
        # Standardize common gym terms
        standardizations = {
            r'\bGym\b': 'Gym',
            r'\bFitness\b': 'Fitness',
            r'\bHealth Club\b': 'Health Club',
            r'\bWellness\b': 'Wellness',
            r'\bYoga\b': 'Yoga',
            r'\bCrossfit\b': 'CrossFit'
        }
        
        for pattern, replacement in standardizations.items():
            df['business_name'] = df['business_name'].str.replace(pattern, replacement, regex=True, case=False)
        
        # Remove very short or invalid names
        df = df[df['business_name'].str.len() >= 3]
        df = df[~df['business_name'].str.lower().isin(['nan', 'none', 'null', ''])]
        
        logger.info(f"Cleaned business names: {len(df)} records remaining")
        return df
    
    def clean_ratings(self, df: pd.DataFrame) -> pd.DataFrame:
        """Clean and validate rating data"""
        logger.info("Cleaning ratings...")
        
        # Convert to numeric, invalid values become NaN
        df['rating'] = pd.to_numeric(df['rating'], errors='coerce')
        
        # Validate rating range (0-5)
        df.loc[df['rating'] < 0, 'rating'] = np.nan
        df.loc[df['rating'] > 5, 'rating'] = np.nan
        
        # Round to 1 decimal place
        df['rating'] = df['rating'].round(1)
        
        logger.info(f"Valid ratings: {df['rating'].notna().sum()}/{len(df)}")
        return df
    
    def clean_addresses(self, df: pd.DataFrame) -> pd.DataFrame:
        """Clean and standardize address data"""
        logger.info("Cleaning addresses...")
        
        if 'address' not in df.columns:
            df['address'] = np.nan
            return df
        
        # Basic cleaning
        df['address'] = df['address'].astype(str)
        df['address'] = df['address'].str.strip()
        df['address'] = df['address'].str.replace(r'\s+', ' ', regex=True)
        
        # Remove addresses that are too short or generic
        df.loc[df['address'].str.len() < 10, 'address'] = np.nan
        df.loc[df['address'].str.lower().isin(['nan', 'none', 'null', '']), 'address'] = np.nan
        
        # Extract area/locality from address
        df['area'] = df['address'].apply(self._extract_area)
        
        logger.info(f"Valid addresses: {df['address'].notna().sum()}/{len(df)}")
        return df
    
    def _extract_area(self, address: str) -> Optional[str]:
        """Extract area/locality from address"""
        if pd.isna(address) or address == 'nan':
            return None
        
        # Common area indicators in Indian addresses
        area_patterns = [
            r'([A-Za-z\s]+)\s+(?:Nagar|Colony|Area|Sector|Phase)',
            r'([A-Za-z\s]+)\s+(?:Road|Street|Lane)',
            r'([A-Za-z\s]+)\s+(?:Market|Chowk|Circle)'
        ]
        
        for pattern in area_patterns:
            match = re.search(pattern, address, re.IGNORECASE)
            if match:
                area = match.group(1).strip()
                if len(area) > 3:
                    return area
        
        # Fallback: take first significant part
        parts = address.split(',')
        if len(parts) >= 2:
            return parts[0].strip()
        
        return None
    
    def clean_phone_numbers(self, df: pd.DataFrame) -> pd.DataFrame:
        """Clean and validate phone numbers"""
        logger.info("Cleaning phone numbers...")
        
        if 'phone' not in df.columns:
            df['phone'] = np.nan
            return df
        
        def clean_phone(phone):
            if pd.isna(phone):
                return None
            
            phone = str(phone)
            # Remove all non-digit characters
            phone = re.sub(r'\D', '', phone)
            
            # Indian phone number validation
            if len(phone) == 10 and phone[0] in '6789':
                return phone
            elif len(phone) == 12 and phone.startswith('91') and phone[2] in '6789':
                return phone[2:]  # Remove country code
            
            return None
        
        df['phone'] = df['phone'].apply(clean_phone)
        
        logger.info(f"Valid phone numbers: {df['phone'].notna().sum()}/{len(df)}")
        return df
    
    def remove_duplicates(self, df: pd.DataFrame) -> pd.DataFrame:
        """Remove duplicate businesses using fuzzy matching"""
        logger.info("Removing duplicates...")
        
        initial_count = len(df)
        
        # Exact duplicates
        df = df.drop_duplicates(subset=['business_name'], keep='first')
        
        # Fuzzy duplicates (similar names)
        df = self._remove_fuzzy_duplicates(df)
        
        final_count = len(df)
        logger.info(f"Removed {initial_count - final_count} duplicates, {final_count} records remaining")
        
        return df
    
    def _remove_fuzzy_duplicates(self, df: pd.DataFrame) -> pd.DataFrame:
        """Remove fuzzy duplicates based on name similarity"""
        try:
            from difflib import SequenceMatcher
            
            def similarity(a, b):
                return SequenceMatcher(None, a.lower(), b.lower()).ratio()
            
            to_remove = set()
            names = df['business_name'].tolist()
            
            for i in range(len(names)):
                if i in to_remove:
                    continue
                
                for j in range(i + 1, len(names)):
                    if j in to_remove:
                        continue
                    
                    if similarity(names[i], names[j]) > 0.85:  # 85% similarity threshold
                        # Keep the one with more complete data
                        row_i = df.iloc[i]
                        row_j = df.iloc[j]
                        
                        score_i = sum([pd.notna(row_i['rating']), pd.notna(row_i['address']), pd.notna(row_i['phone'])])
                        score_j = sum([pd.notna(row_j['rating']), pd.notna(row_j['address']), pd.notna(row_j['phone'])])
                        
                        if score_i >= score_j:
                            to_remove.add(j)
                        else:
                            to_remove.add(i)
                            break
            
            df = df.drop(df.index[list(to_remove)])
            logger.info(f"Removed {len(to_remove)} fuzzy duplicates")
            
        except ImportError:
            logger.warning("difflib not available, skipping fuzzy duplicate removal")
        
        return df
    
    def categorize_businesses(self, df: pd.DataFrame) -> pd.DataFrame:
        """Categorize businesses by type"""
        logger.info("Categorizing businesses...")
        
        def categorize(name):
            name_lower = name.lower()
            
            if any(word in name_lower for word in ['yoga', 'pilates', 'meditation']):
                return 'Yoga/Pilates Studio'
            elif any(word in name_lower for word in ['crossfit', 'functional', 'boot camp']):
                return 'Functional Fitness'
            elif any(word in name_lower for word in ['ladies', 'women', 'female']):
                return 'Women-Only Gym'
            elif any(word in name_lower for word in ['boxing', 'martial arts', 'mma', 'karate']):
                return 'Martial Arts/Boxing'
            elif any(word in name_lower for word in ['health club', 'wellness', 'spa']):
                return 'Health Club/Wellness'
            elif any(word in name_lower for word in ['gym', 'fitness', 'bodybuilding']):
                return 'Traditional Gym'
            else:
                return 'Other Fitness'
        
        df['business_category'] = df['business_name'].apply(categorize)
        
        # Log category distribution
        category_counts = df['business_category'].value_counts()
        logger.info(f"Business categories: {category_counts.to_dict()}")
        
        return df
    
    def validate_data_quality(self, df: pd.DataFrame) -> Dict:
        """Validate data quality and generate report"""
        logger.info("Validating data quality...")
        
        total_records = len(df)
        
        quality_report = {
            'total_records': total_records,
            'data_completeness': {
                'business_name': round((df['business_name'].notna().sum() / total_records * 100), 2),
                'rating': round((df['rating'].notna().sum() / total_records * 100), 2),
                'address': round((df['address'].notna().sum() / total_records * 100), 2),
                'phone': round((df['phone'].notna().sum() / total_records * 100), 2) if 'phone' in df.columns else 0
            },
            'data_quality_metrics': {
                'avg_rating': round(df['rating'].mean(), 2) if df['rating'].notna().any() and not pd.isna(df['rating'].mean()) else None,
                'rating_distribution': df['rating'].value_counts().to_dict() if df['rating'].notna().any() else {},
                'category_distribution': df['business_category'].value_counts().to_dict() if 'business_category' in df.columns else {},
                'unique_business_names': df['business_name'].nunique(),
                'duplicate_rate': round(((total_records - df['business_name'].nunique()) / total_records * 100), 2)
            }
        }
        
        self.validation_report = quality_report
        
        # Log quality summary
        logger.info(f"Data quality summary:")
        logger.info(f"- Total records: {total_records}")
        logger.info(f"- Completeness: {quality_report['data_completeness']}")
        logger.info(f"- Average rating: {quality_report['data_quality_metrics']['avg_rating']}")
        
        return quality_report
    
    def process_all_data(self, input_file: str, output_file: str = None) -> pd.DataFrame:
        """Complete data processing pipeline"""
        logger.info("Starting complete data processing pipeline...")
        
        # Load data
        df = self.load_scraped_data(input_file)
        if df.empty:
            return df
        
        # Clean data step by step
        df = self.clean_business_names()
        df = self.clean_ratings(df)
        df = self.clean_addresses(df)
        df = self.clean_phone_numbers(df)
        df = self.remove_duplicates(df)
        df = self.categorize_businesses(df)
        
        # Validate quality
        quality_report = self.validate_data_quality(df)
        
        # Save processed data
        if output_file is None:
            output_file = 'data/processed/cleaned_gym_data.csv'
        
        df.to_csv(output_file, index=False, encoding='utf-8')
        logger.info(f"Processed data saved to: {output_file}")
        
        # Save quality report
        report_file = output_file.replace('.csv', '_quality_report.json')
        with open(report_file, 'w') as f:
            json.dump(quality_report, f, indent=2)
        
        self.clean_data = df
        logger.info("Data processing pipeline completed successfully!")
        
        return df

def main():
    """Example usage of the data processor"""
    processor = FitnessDataProcessor()
    
    # Process data from different phases
    phase_files = [
        'data/processed/phase1_results.csv',
        'data/processed/phase2_results.csv', 
        'data/processed/phase3_results.csv',
        'data/processed/phase4_ultimate_results.csv'
    ]
    
    all_data = []
    
    for file_path in phase_files:
        if Path(file_path).exists():
            logger.info(f"Processing {file_path}")
            df = processor.process_all_data(file_path, 
                                          file_path.replace('results.csv', 'cleaned.csv'))
            if not df.empty:
                all_data.append(df)
    
    # Combine all data if multiple files processed
    if len(all_data) > 1:
        combined_data = pd.concat(all_data, ignore_index=True)
        final_processor = FitnessDataProcessor()
        final_processor.data = combined_data
        
        # Process combined data
        final_clean = final_processor.remove_duplicates(combined_data)
        final_clean = final_processor.categorize_businesses(final_clean)
        final_quality = final_processor.validate_data_quality(final_clean)
        
        # Save final combined dataset
        final_clean.to_csv('data/output/pune_gyms_final.csv', index=False, encoding='utf-8')
        
        with open('data/output/final_quality_report.json', 'w') as f:
            json.dump(final_quality, f, indent=2)
        
        logger.info(f"Final combined dataset: {len(final_clean)} unique businesses")
        print("\nFinal Dataset Summary:")
        print(f"Total businesses: {len(final_clean)}")
        print(f"Average rating: {final_clean['rating'].mean():.2f}")
        print(f"Businesses with addresses: {final_clean['address'].notna().sum()}")
        print(f"Category distribution:")
        print(final_clean['business_category'].value_counts())

if __name__ == "__main__":
    main()