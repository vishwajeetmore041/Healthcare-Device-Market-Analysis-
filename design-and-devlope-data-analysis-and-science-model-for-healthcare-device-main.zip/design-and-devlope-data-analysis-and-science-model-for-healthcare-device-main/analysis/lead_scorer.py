"""
Lead Scoring Model for Fitness Device Sales

This module implements a machine learning-based lead scoring system to prioritize
gym and fitness center prospects for body composition analyzer sales.
The model considers multiple factors including business quality, market position,
and potential for new technology adoption.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import mean_squared_error, r2_score
import joblib
import logging
from pathlib import Path
import json
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class FitnessLeadScorer:
    def __init__(self):
        """Initialize the lead scoring model"""
        self.model = None
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_names = []
        self.scoring_weights = {
            'rating_score': 0.25,
            'market_position_score': 0.20,
            'technology_readiness_score': 0.20,
            'business_size_score': 0.15,
            'competition_score': 0.10,
            'accessibility_score': 0.10
        }
        
    def load_data(self, data_file: str) -> pd.DataFrame:
        """Load and prepare data for lead scoring"""
        try:
            if not Path(data_file).exists():
                logger.error(f"Data file not found: {data_file}")
                return pd.DataFrame()
            
            data = pd.read_csv(data_file, encoding='utf-8')
            logger.info(f"Loaded {len(data)} businesses for lead scoring")
            return data
            
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            return pd.DataFrame()
    
    def engineer_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """Engineer features for lead scoring model"""
        logger.info("Engineering features for lead scoring...")
        
        df = data.copy()
        
        # 1. Rating-based features
        df['rating_score'] = self._calculate_rating_score(df)
        
        # 2. Market position features
        df['market_position_score'] = self._calculate_market_position_score(df)
        
        # 3. Technology readiness features
        df['technology_readiness_score'] = self._calculate_technology_readiness_score(df)
        
        # 4. Business size estimation
        df['business_size_score'] = self._estimate_business_size_score(df)
        
        # 5. Competition density features
        df['competition_score'] = self._calculate_competition_score(df)
        
        # 6. Data accessibility features
        df['accessibility_score'] = self._calculate_accessibility_score(df)
        
        # 7. Combined lead score
        df['lead_score'] = self._calculate_composite_lead_score(df)
        
        logger.info("Feature engineering completed")
        return df
    
    def _calculate_rating_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate rating-based scoring component"""
        if 'rating' not in df.columns:
            return pd.Series([5.0] * len(df))  # Neutral score if no ratings
        
        # Normalize ratings to 0-10 scale
        rating_score = df['rating'].fillna(3.0)  # Fill missing with average
        
        # Higher ratings = higher scores, but not linearly
        # We want businesses that are successful but might benefit from new equipment
        rating_score = np.where(rating_score >= 4.5, 8.0,  # Very high - established but may need edge
                               np.where(rating_score >= 4.0, 10.0,  # High - prime targets
                                       np.where(rating_score >= 3.5, 9.0,  # Good - growth potential
                                               np.where(rating_score >= 3.0, 7.0,  # Average - needs improvement
                                                       np.where(rating_score >= 2.5, 6.0,  # Below average
                                                               3.0)))))  # Poor - risky
        
        return pd.Series(rating_score)
    
    def _calculate_market_position_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate market position scoring component"""
        scores = []
        
        for _, row in df.iterrows():
            score = 5.0  # Base score
            
            # Category-based scoring
            if 'business_category' in df.columns:
                category = str(row.get('business_category', '')).lower()
                
                if 'traditional gym' in category:
                    score += 3.0  # Primary target
                elif 'health club' in category or 'wellness' in category:
                    score += 2.5  # Secondary target
                elif 'functional fitness' in category or 'crossfit' in category:
                    score += 2.0  # Modern, tech-friendly
                elif 'women-only' in category:
                    score += 1.5  # Niche market
                else:
                    score += 1.0  # Other categories
            
            # Business name analysis for market position indicators
            business_name = str(row.get('business_name', '')).lower()
            
            # Established chains or brands
            established_indicators = ['gold', 'anytime', 'planet', 'fitness first', 'talwalkars']
            if any(indicator in business_name for indicator in established_indicators):
                score += 1.5
            
            # Premium indicators
            premium_indicators = ['premium', 'elite', 'luxury', 'club', 'spa']
            if any(indicator in business_name for indicator in premium_indicators):
                score += 1.0
            
            scores.append(min(score, 10.0))  # Cap at 10
        
        return pd.Series(scores)
    
    def _calculate_technology_readiness_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate technology readiness scoring component"""
        scores = []
        
        for _, row in df.iterrows():
            score = 5.0  # Base score
            
            business_name = str(row.get('business_name', '')).lower()
            
            # Modern/tech-forward indicators
            modern_indicators = ['smart', 'digital', 'tech', 'advanced', 'innovation', 'modern', '24/7', 'app']
            if any(indicator in business_name for indicator in modern_indicators):
                score += 2.0
            
            # Fitness tracking/health focus indicators
            health_tech_indicators = ['health', 'wellness', 'body', 'performance', 'training', 'science']
            if any(indicator in business_name for indicator in health_tech_indicators):
                score += 1.5
            
            # Category-based tech readiness
            if 'business_category' in df.columns:
                category = str(row.get('business_category', '')).lower()
                
                if 'functional fitness' in category or 'crossfit' in category:
                    score += 1.5  # Usually more tech-forward
                elif 'traditional gym' in category:
                    score += 1.0  # Moderate tech adoption
                elif 'yoga' in category:
                    score -= 0.5  # Often less tech-focused
            
            # Age/establishment indicators (newer businesses more likely to adopt)
            traditional_indicators = ['old', 'traditional', 'classic', 'heritage']
            if any(indicator in business_name for indicator in traditional_indicators):
                score -= 1.0
            
            scores.append(max(min(score, 10.0), 1.0))  # Cap between 1-10
        
        return pd.Series(scores)
    
    def _estimate_business_size_score(self, df: pd.DataFrame) -> pd.Series:
        """Estimate business size scoring component"""
        scores = []
        
        for _, row in df.iterrows():
            score = 5.0  # Base score
            
            business_name = str(row.get('business_name', '')).lower()
            
            # Size indicators in name
            large_indicators = ['group', 'chain', 'corporate', 'international', 'multi', 'network']
            if any(indicator in business_name for indicator in large_indicators):
                score += 2.0
            
            # Premium/large facility indicators
            premium_size_indicators = ['club', 'center', 'complex', 'studio', 'academy', 'institute']
            if any(indicator in business_name for indicator in premium_size_indicators):
                score += 1.0
            
            # Small business indicators
            small_indicators = ['home', 'personal', 'private', 'studio']
            if any(indicator in business_name for indicator in small_indicators):
                score -= 1.0
            
            # Has complete information (suggests established business)
            info_completeness = 0
            if pd.notna(row.get('rating')):
                info_completeness += 1
            if pd.notna(row.get('address')):
                info_completeness += 1
            if pd.notna(row.get('phone')):
                info_completeness += 1
            
            score += info_completeness * 0.5
            
            scores.append(max(min(score, 10.0), 1.0))
        
        return pd.Series(scores)
    
    def _calculate_competition_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate competition density scoring component"""
        # If we have area information, calculate competition density
        if 'area' in df.columns:
            area_counts = df['area'].value_counts()
            area_competition = df['area'].map(area_counts)
            
            # Inverse relationship: fewer competitors = higher score
            max_competition = area_competition.max()
            competition_scores = 10 - (area_competition / max_competition * 8)  # Scale 2-10
            
            return competition_scores.fillna(5.0)
        else:
            # Without area data, assign neutral scores
            return pd.Series([5.0] * len(df))
    
    def _calculate_accessibility_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate data accessibility scoring component"""
        scores = []
        
        for _, row in df.iterrows():
            score = 1.0  # Base score
            
            # Data completeness indicates business accessibility
            if pd.notna(row.get('business_name')):
                score += 2.0
            if pd.notna(row.get('rating')):
                score += 2.0
            if pd.notna(row.get('address')):
                score += 2.0
            if pd.notna(row.get('phone')):
                score += 2.0
            if pd.notna(row.get('website')):
                score += 1.0
            
            scores.append(min(score, 10.0))
        
        return pd.Series(scores)
    
    def _calculate_composite_lead_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate composite lead score using weighted components"""
        composite_scores = []
        
        for _, row in df.iterrows():
            weighted_score = 0
            
            for component, weight in self.scoring_weights.items():
                component_score = row.get(component, 5.0)
                weighted_score += component_score * weight
            
            # Add some randomness to break ties and simulate market dynamics
            noise = np.random.normal(0, 0.1)  # Small random factor
            final_score = max(min(weighted_score + noise, 10.0), 1.0)
            
            composite_scores.append(final_score)
        
        return pd.Series(composite_scores)
    
    def prepare_training_data(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare data for model training"""
        logger.info("Preparing training data...")
        
        # Select features for training
        feature_columns = [
            'rating_score', 'market_position_score', 'technology_readiness_score',
            'business_size_score', 'competition_score', 'accessibility_score'
        ]
        
        # Prepare features
        X = df[feature_columns].fillna(5.0)  # Fill missing with neutral scores
        
        # Target variable (lead_score)
        y = df['lead_score']
        
        self.feature_names = feature_columns
        
        logger.info(f"Prepared training data: {X.shape[0]} samples, {X.shape[1]} features")
        return X.values, y.values
    
    def train_model(self, X: np.ndarray, y: np.ndarray) -> Dict:
        """Train the lead scoring model"""
        logger.info("Training lead scoring model...")
        
        # Split data for validation
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Train model (using Random Forest for interpretability)
        self.model = RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42
        )
        
        self.model.fit(X_train_scaled, y_train)
        
        # Evaluate model
        train_pred = self.model.predict(X_train_scaled)
        test_pred = self.model.predict(X_test_scaled)
        
        train_r2 = r2_score(y_train, train_pred)
        test_r2 = r2_score(y_test, test_pred)
        train_rmse = np.sqrt(mean_squared_error(y_train, train_pred))
        test_rmse = np.sqrt(mean_squared_error(y_test, test_pred))
        
        # Feature importance
        feature_importance = dict(zip(self.feature_names, self.model.feature_importances_))
        
        results = {
            'train_r2': train_r2,
            'test_r2': test_r2,
            'train_rmse': train_rmse,
            'test_rmse': test_rmse,
            'feature_importance': feature_importance
        }
        
        logger.info(f"Model training completed - Test R²: {test_r2:.3f}, Test RMSE: {test_rmse:.3f}")
        
        return results
    
    def score_leads(self, df: pd.DataFrame) -> pd.DataFrame:
        """Score all leads and rank them"""
        logger.info("Scoring leads...")
        
        if self.model is None:
            logger.error("Model not trained yet")
            return df
        
        # Engineer features
        df_featured = self.engineer_features(df)
        
        # Prepare features for prediction
        feature_columns = self.feature_names
        X = df_featured[feature_columns].fillna(5.0)
        X_scaled = self.scaler.transform(X)
        
        # Predict lead scores
        predicted_scores = self.model.predict(X_scaled)
        df_featured['ml_lead_score'] = predicted_scores
        
        # Create priority rankings
        df_featured['lead_rank'] = df_featured['ml_lead_score'].rank(method='dense', ascending=False)
        df_featured['priority_tier'] = pd.cut(df_featured['ml_lead_score'], 
                                            bins=[0, 3, 5, 7, 10], 
                                            labels=['Low', 'Medium', 'High', 'Very High'])
        
        # Sort by lead score
        df_scored = df_featured.sort_values('ml_lead_score', ascending=False)
        
        logger.info(f"Lead scoring completed for {len(df_scored)} businesses")
        
        return df_scored
    
    def generate_sales_recommendations(self, scored_df: pd.DataFrame) -> Dict:
        """Generate actionable sales recommendations"""
        logger.info("Generating sales recommendations...")
        
        recommendations = {
            'priority_targets': [],
            'quick_wins': [],
            'long_term_prospects': [],
            'avoid_list': [],
            'market_segments': {},
            'sales_strategy': {}
        }
        
        # Priority targets (top 20% by score)
        top_20_percent = int(len(scored_df) * 0.2)
        priority_targets = scored_df.head(top_20_percent)
        
        for _, business in priority_targets.iterrows():
            recommendations['priority_targets'].append({
                'business_name': business['business_name'],
                'lead_score': round(business['ml_lead_score'], 2),
                'priority_tier': business['priority_tier'],
                'key_factors': self._identify_key_factors(business),
                'sales_approach': self._suggest_sales_approach(business)
            })
        
        # Quick wins (high accessibility + medium-high score)
        quick_wins = scored_df[
            (scored_df['accessibility_score'] >= 8) & 
            (scored_df['ml_lead_score'] >= 6) & 
            (scored_df['ml_lead_score'] < 8)
        ]
        
        for _, business in quick_wins.head(10).iterrows():
            recommendations['quick_wins'].append({
                'business_name': business['business_name'],
                'lead_score': round(business['ml_lead_score'], 2),
                'reason': 'High accessibility with good potential'
            })
        
        # Market segment analysis
        if 'business_category' in scored_df.columns:
            segment_analysis = scored_df.groupby('business_category').agg({
                'ml_lead_score': ['mean', 'count'],
                'rating': 'mean'
            }).round(2)
            
            # Flatten the multi-level column names to avoid tuple keys
            segment_dict = {}
            for category in segment_analysis.index:
                segment_dict[category] = {
                    'avg_lead_score': segment_analysis.loc[category, ('ml_lead_score', 'mean')],
                    'business_count': segment_analysis.loc[category, ('ml_lead_score', 'count')],
                    'avg_rating': segment_analysis.loc[category, ('rating', 'mean')] if not pd.isna(segment_analysis.loc[category, ('rating', 'mean')]) else None
                }
            
            recommendations['market_segments'] = segment_dict
        
        # Sales strategy recommendations
        avg_score = scored_df['ml_lead_score'].mean()
        recommendations['sales_strategy'] = {
            'total_prospects': len(scored_df),
            'high_priority_count': len(scored_df[scored_df['priority_tier'] == 'Very High']),
            'recommended_focus': 'Very High' if len(scored_df[scored_df['priority_tier'] == 'Very High']) > 10 else 'High',
            'market_avg_score': round(avg_score, 2),
            'conversion_strategy': self._recommend_conversion_strategy(scored_df)
        }
        
        logger.info("Sales recommendations generated")
        return recommendations
    
    def _identify_key_factors(self, business_row) -> List[str]:
        """Identify key factors driving the lead score"""
        factors = []
        
        if business_row.get('rating_score', 0) >= 8:
            factors.append('Strong market performance')
        if business_row.get('technology_readiness_score', 0) >= 7:
            factors.append('High tech adoption potential')
        if business_row.get('market_position_score', 0) >= 8:
            factors.append('Established market position')
        if business_row.get('business_size_score', 0) >= 7:
            factors.append('Substantial business size')
        if business_row.get('competition_score', 0) >= 7:
            factors.append('Low competition environment')
        
        return factors[:3]  # Return top 3 factors
    
    def _suggest_sales_approach(self, business_row) -> str:
        """Suggest sales approach based on business characteristics"""
        score = business_row.get('ml_lead_score', 5)
        tech_score = business_row.get('technology_readiness_score', 5)
        rating = business_row.get('rating_score', 5)
        
        if score >= 8 and tech_score >= 7:
            return "Direct approach - emphasize innovation and competitive advantage"
        elif score >= 7 and rating >= 8:
            return "Consultative approach - focus on enhancing existing success"
        elif score >= 6:
            return "Educational approach - demonstrate ROI and benefits"
        else:
            return "Relationship building - long-term nurturing required"
    
    def _recommend_conversion_strategy(self, scored_df: pd.DataFrame) -> str:
        """Recommend overall conversion strategy"""
        high_priority_count = len(scored_df[scored_df['priority_tier'] == 'Very High'])
        
        if high_priority_count >= 20:
            return "Focus on top-tier prospects with dedicated sales team"
        elif high_priority_count >= 10:
            return "Balanced approach - prioritize high-value while maintaining pipeline"
        else:
            return "Broad market approach with systematic lead nurturing"
    
    def save_model(self, model_path: str = 'analysis/lead_scoring_model.joblib'):
        """Save the trained model and preprocessing components"""
        if self.model is None:
            logger.error("No model to save")
            return
        
        model_package = {
            'model': self.model,
            'scaler': self.scaler,
            'feature_names': self.feature_names,
            'scoring_weights': self.scoring_weights
        }
        
        joblib.dump(model_package, model_path)
        logger.info(f"Model saved to {model_path}")
    
    def load_model(self, model_path: str):
        """Load a trained model"""
        try:
            model_package = joblib.load(model_path)
            self.model = model_package['model']
            self.scaler = model_package['scaler']
            self.feature_names = model_package['feature_names']
            self.scoring_weights = model_package['scoring_weights']
            
            logger.info(f"Model loaded from {model_path}")
            
        except Exception as e:
            logger.error(f"Error loading model: {e}")

def main():
    """Example usage of the lead scoring system"""
    
    # Look for cleaned data
    data_files = [
        'data/output/pune_gyms_final.csv',
        'data/processed/cleaned_gym_data.csv',
        'data/processed/phase4_ultimate_cleaned.csv'
    ]
    
    data_file = None
    for file_path in data_files:
        if Path(file_path).exists():
            data_file = file_path
            break
    
    if not data_file:
        logger.error("No cleaned data file found. Please run data processing first.")
        return
    
    # Initialize lead scorer
    scorer = FitnessLeadScorer()
    
    # Load and prepare data
    data = scorer.load_data(data_file)
    if data.empty:
        return
    
    # Engineer features
    featured_data = scorer.engineer_features(data)
    
    # Train model
    X, y = scorer.prepare_training_data(featured_data)
    training_results = scorer.train_model(X, y)
    
    # Score all leads
    scored_data = scorer.score_leads(data)
    
    # Generate recommendations
    recommendations = scorer.generate_sales_recommendations(scored_data)
    
    # Save results
    scored_data.to_csv('data/output/scored_leads.csv', index=False, encoding='utf-8')
    
    with open('data/output/sales_recommendations.json', 'w', encoding='utf-8') as f:
        json.dump(recommendations, f, indent=2, ensure_ascii=False, default=str)
    
    # Save model
    scorer.save_model('analysis/lead_scoring_model.joblib')
    
    # Print summary
    print("\n" + "="*60)
    print("LEAD SCORING ANALYSIS COMPLETE")
    print("="*60)
    print(f"Total businesses scored: {len(scored_data)}")
    print(f"Model performance (R²): {training_results['test_r2']:.3f}")
    print(f"Priority targets identified: {len(recommendations['priority_targets'])}")
    print(f"Quick wins identified: {len(recommendations['quick_wins'])}")
    
    print(f"\nTop 5 Priority Targets:")
    for i, target in enumerate(recommendations['priority_targets'][:5]):
        print(f"  {i+1}. {target['business_name']} (Score: {target['lead_score']})")
    
    print(f"\nFiles generated:")
    print(f"  • Scored leads: data/output/scored_leads.csv")
    print(f"  • Sales recommendations: data/output/sales_recommendations.json")
    print(f"  • Trained model: analysis/lead_scoring_model.joblib")

if __name__ == "__main__":
    main()