"""
Market Analysis and Visualization Tools

This module provides comprehensive market analysis capabilities including:
- Exploratory Data Analysis (EDA)
- Market density and hotspot analysis
- Competitor analysis and ratings distribution
- Geographic clustering and insights
- Business visualization and reporting
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import logging
from pathlib import Path
import json
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Set up plotting style
plt.style.use('default')
sns.set_palette("husl")

class FitnessMarketAnalyzer:
    def __init__(self, data_file: str):
        """Initialize the market analyzer with cleaned data"""
        self.data_file = data_file
        self.data = None
        self.analysis_results = {}
        self.load_data()
        
    def load_data(self):
        """Load the cleaned gym data"""
        try:
            if not Path(self.data_file).exists():
                logger.error(f"Data file not found: {self.data_file}")
                return
                
            self.data = pd.read_csv(self.data_file, encoding='utf-8')
            logger.info(f"Loaded {len(self.data)} businesses for analysis")
            
        except Exception as e:
            logger.error(f"Error loading data: {e}")
    
    def generate_market_overview(self) -> Dict:
        """Generate comprehensive market overview"""
        if self.data is None or self.data.empty:
            return {}
        
        logger.info("Generating market overview...")
        
        overview = {
            'total_businesses': len(self.data),
            'avg_rating': self.data['rating'].mean() if 'rating' in self.data.columns else None,
            'rating_std': self.data['rating'].std() if 'rating' in self.data.columns else None,
            'businesses_with_ratings': self.data['rating'].notna().sum() if 'rating' in self.data.columns else 0,
            'businesses_with_addresses': self.data['address'].notna().sum() if 'address' in self.data.columns else 0,
            'businesses_with_phones': self.data['phone'].notna().sum() if 'phone' in self.data.columns else 0,
        }
        
        # Category analysis
        if 'business_category' in self.data.columns:
            overview['category_distribution'] = self.data['business_category'].value_counts().to_dict()
        
        # Rating distribution
        if 'rating' in self.data.columns and self.data['rating'].notna().any():
            overview['rating_distribution'] = {
                'excellent_4_5': len(self.data[self.data['rating'] >= 4.0]),
                'good_3_4': len(self.data[(self.data['rating'] >= 3.0) & (self.data['rating'] < 4.0)]),
                'average_2_3': len(self.data[(self.data['rating'] >= 2.0) & (self.data['rating'] < 3.0)]),
                'poor_below_2': len(self.data[self.data['rating'] < 2.0])
            }
        
        self.analysis_results['market_overview'] = overview
        logger.info("Market overview completed")
        
        return overview
    
    def analyze_competition_landscape(self) -> Dict:
        """Analyze the competitive landscape"""
        logger.info("Analyzing competition landscape...")
        
        competition_analysis = {}
        
        if 'rating' in self.data.columns and self.data['rating'].notna().any():
            rated_businesses = self.data[self.data['rating'].notna()]
            
            competition_analysis.update({
                'top_performers': rated_businesses.nlargest(10, 'rating')[['business_name', 'rating', 'business_category']].to_dict('records'),
                'bottom_performers': rated_businesses.nsmallest(5, 'rating')[['business_name', 'rating', 'business_category']].to_dict('records'),
                'rating_percentiles': {
                    '25th_percentile': rated_businesses['rating'].quantile(0.25),
                    '50th_percentile': rated_businesses['rating'].quantile(0.50),
                    '75th_percentile': rated_businesses['rating'].quantile(0.75),
                    '90th_percentile': rated_businesses['rating'].quantile(0.90)
                }
            })
        
        # Category-wise analysis
        if 'business_category' in self.data.columns:
            category_stats = {}
            for category in self.data['business_category'].unique():
                category_data = self.data[self.data['business_category'] == category]
                category_stats[category] = {
                    'count': len(category_data),
                    'avg_rating': category_data['rating'].mean() if 'rating' in category_data.columns else None,
                    'market_share': len(category_data) / len(self.data) * 100
                }
            
            competition_analysis['category_analysis'] = category_stats
        
        self.analysis_results['competition'] = competition_analysis
        logger.info("Competition analysis completed")
        
        return competition_analysis
    
    def identify_market_opportunities(self) -> Dict:
        """Identify market opportunities and gaps"""
        logger.info("Identifying market opportunities...")
        
        opportunities = {}
        
        # Underserved categories
        if 'business_category' in self.data.columns:
            category_counts = self.data['business_category'].value_counts()
            total_businesses = len(self.data)
            
            underserved_categories = []
            for category, count in category_counts.items():
                market_share = count / total_businesses * 100
                if market_share < 10:  # Categories with less than 10% market share
                    underserved_categories.append({
                        'category': category,
                        'current_count': count,
                        'market_share': market_share,
                        'opportunity_score': (10 - market_share) * 2  # Simple scoring
                    })
            
            opportunities['underserved_categories'] = sorted(underserved_categories, 
                                                           key=lambda x: x['opportunity_score'], 
                                                           reverse=True)
        
        # Quality gaps
        if 'rating' in self.data.columns and self.data['rating'].notna().any():
            avg_rating = self.data['rating'].mean()
            poor_performers = self.data[self.data['rating'] < avg_rating - 0.5]
            
            opportunities['quality_improvement_targets'] = {
                'businesses_below_avg': len(poor_performers),
                'avg_market_rating': avg_rating,
                'improvement_potential': poor_performers[['business_name', 'rating', 'business_category']].to_dict('records')[:10]
            }
        
        # Geographic opportunities (if area data available)
        if 'area' in self.data.columns:
            area_density = self.data['area'].value_counts()
            
            opportunities['geographic_density'] = {
                'high_density_areas': area_density.head(5).to_dict(),
                'low_density_areas': area_density.tail(5).to_dict(),
                'expansion_opportunities': area_density[area_density <= 2].to_dict()  # Areas with 2 or fewer gyms
            }
        
        self.analysis_results['opportunities'] = opportunities
        logger.info("Market opportunity analysis completed")
        
        return opportunities
    
    def create_market_overview_chart(self, save_path: str = 'data/output/market_overview.png'):
        """Create comprehensive market overview visualization"""
        logger.info("Creating market overview chart...")
        
        # Create subplots
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('Pune Gym Market Overview', fontsize=16, fontweight='bold')
        
        # 1. Business Category Distribution
        if 'business_category' in self.data.columns:
            category_counts = self.data['business_category'].value_counts()
            axes[0, 0].pie(category_counts.values, labels=category_counts.index, autopct='%1.1f%%', startangle=90)
            axes[0, 0].set_title('Business Category Distribution')
        
        # 2. Rating Distribution
        if 'rating' in self.data.columns and self.data['rating'].notna().any():
            self.data[self.data['rating'].notna()]['rating'].hist(bins=20, ax=axes[0, 1], alpha=0.7, color='skyblue')
            axes[0, 1].set_title('Rating Distribution')
            axes[0, 1].set_xlabel('Rating')
            axes[0, 1].set_ylabel('Number of Businesses')
            axes[0, 1].axvline(self.data['rating'].mean(), color='red', linestyle='--', label=f'Average: {self.data["rating"].mean():.2f}')
            axes[0, 1].legend()
        
        # 3. Data Completeness
        completeness_data = {
            'Business Name': (self.data['business_name'].notna().sum() / len(self.data)) * 100,
            'Rating': (self.data['rating'].notna().sum() / len(self.data)) * 100 if 'rating' in self.data.columns else 0,
            'Address': (self.data['address'].notna().sum() / len(self.data)) * 100 if 'address' in self.data.columns else 0,
            'Phone': (self.data['phone'].notna().sum() / len(self.data)) * 100 if 'phone' in self.data.columns else 0
        }
        
        bars = axes[1, 0].bar(completeness_data.keys(), completeness_data.values(), color=['green', 'blue', 'orange', 'red'])
        axes[1, 0].set_title('Data Completeness (%)')
        axes[1, 0].set_ylabel('Completion Percentage')
        axes[1, 0].set_ylim(0, 100)
        
        # Add value labels on bars
        for bar in bars:
            height = bar.get_height()
            axes[1, 0].text(bar.get_x() + bar.get_width()/2., height + 1, f'{height:.1f}%', 
                           ha='center', va='bottom')
        
        # 4. Top Rated Businesses
        if 'rating' in self.data.columns and self.data['rating'].notna().any():
            top_businesses = self.data.nlargest(10, 'rating')
            y_pos = np.arange(len(top_businesses))
            
            axes[1, 1].barh(y_pos, top_businesses['rating'], color='gold')
            axes[1, 1].set_yticks(y_pos)
            axes[1, 1].set_yticklabels([name[:20] + '...' if len(name) > 20 else name 
                                      for name in top_businesses['business_name']], fontsize=8)
            axes[1, 1].set_title('Top 10 Rated Businesses')
            axes[1, 1].set_xlabel('Rating')
            axes[1, 1].invert_yaxis()
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"Market overview chart saved to {save_path}")
    
    def create_interactive_dashboard(self, save_path: str = 'data/output/interactive_dashboard.html'):
        """Create an interactive dashboard using Plotly"""
        logger.info("Creating interactive dashboard...")
        
        # Create subplots
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Business Categories', 'Rating Distribution', 
                          'Category vs Rating', 'Geographic Distribution'),
            specs=[[{"type": "pie"}, {"type": "histogram"}],
                   [{"type": "box"}, {"type": "bar"}]]
        )
        
        # 1. Pie chart for business categories
        if 'business_category' in self.data.columns:
            category_counts = self.data['business_category'].value_counts()
            fig.add_trace(
                go.Pie(labels=category_counts.index, values=category_counts.values, name="Categories"),
                row=1, col=1
            )
        
        # 2. Histogram for ratings
        if 'rating' in self.data.columns and self.data['rating'].notna().any():
            fig.add_trace(
                go.Histogram(x=self.data['rating'], name="Ratings", nbinsx=20),
                row=1, col=2
            )
        
        # 3. Box plot for category vs rating
        if 'business_category' in self.data.columns and 'rating' in self.data.columns:
            for category in self.data['business_category'].unique():
                category_data = self.data[self.data['business_category'] == category]
                fig.add_trace(
                    go.Box(y=category_data['rating'], name=category),
                    row=2, col=1
                )
        
        # 4. Geographic distribution (if area data available)
        if 'area' in self.data.columns:
            area_counts = self.data['area'].value_counts().head(10)
            fig.add_trace(
                go.Bar(x=area_counts.index, y=area_counts.values, name="Areas"),
                row=2, col=2
            )
        
        # Update layout
        fig.update_layout(
            title_text="Pune Fitness Market Analysis Dashboard",
            title_x=0.5,
            height=800,
            showlegend=False
        )
        
        # Save as HTML
        fig.write_html(save_path)
        logger.info(f"Interactive dashboard saved to {save_path}")
    
    def generate_business_insights(self) -> Dict:
        """Generate actionable business insights"""
        logger.info("Generating business insights...")
        
        insights = {
            'key_findings': [],
            'recommendations': [],
            'market_size_estimation': {},
            'competitive_positioning': {}
        }
        
        # Key findings
        total_businesses = len(self.data)
        insights['key_findings'].append(f"Total identified fitness businesses in Pune: {total_businesses}")
        
        if 'rating' in self.data.columns and self.data['rating'].notna().any():
            avg_rating = self.data['rating'].mean()
            insights['key_findings'].append(f"Average market rating: {avg_rating:.2f}/5.0")
            
            high_rated = len(self.data[self.data['rating'] >= 4.0])
            insights['key_findings'].append(f"{high_rated} businesses ({high_rated/total_businesses*100:.1f}%) have ratings ≥4.0")
        
        # Category insights
        if 'business_category' in self.data.columns:
            dominant_category = self.data['business_category'].value_counts().index[0]
            dominant_count = self.data['business_category'].value_counts().iloc[0]
            insights['key_findings'].append(f"{dominant_category} is the dominant category with {dominant_count} businesses")
        
        # Recommendations
        if 'rating' in self.data.columns:
            poor_performers = len(self.data[self.data['rating'] < 3.0])
            if poor_performers > 0:
                insights['recommendations'].append(f"Target {poor_performers} low-rated businesses for acquisition or partnership opportunities")
        
        if 'business_category' in self.data.columns:
            category_counts = self.data['business_category'].value_counts()
            underserved = category_counts[category_counts < category_counts.mean()]
            if len(underserved) > 0:
                insights['recommendations'].append(f"Consider focusing on underserved categories: {', '.join(underserved.index[:3])}")
        
        # Market size estimation
        insights['market_size_estimation'] = {
            'total_addressable_market': total_businesses,
            'serviceable_addressable_market': len(self.data[self.data['business_category'].isin(['Traditional Gym', 'Health Club/Wellness'])]) if 'business_category' in self.data.columns else total_businesses,
            'immediate_target_market': len(self.data[self.data['rating'] < 4.0]) if 'rating' in self.data.columns else int(total_businesses * 0.6)
        }
        
        self.analysis_results['insights'] = insights
        logger.info("Business insights generated")
        
        return insights
    
    def save_analysis_report(self, output_path: str = 'data/output/market_analysis_report.json'):
        """Save comprehensive analysis report"""
        logger.info("Saving analysis report...")
        
        # Ensure all analyses are completed
        if not self.analysis_results:
            self.generate_market_overview()
            self.analyze_competition_landscape()
            self.identify_market_opportunities()
            self.generate_business_insights()
        
        # Add metadata
        self.analysis_results['metadata'] = {
            'analysis_date': pd.Timestamp.now().isoformat(),
            'data_source': self.data_file,
            'total_records_analyzed': len(self.data) if self.data is not None else 0
        }
        
        # Save to JSON
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.analysis_results, f, indent=2, ensure_ascii=False, default=str)
        
        logger.info(f"Analysis report saved to {output_path}")
    
    def run_complete_analysis(self):
        """Run the complete market analysis pipeline"""
        logger.info("Running complete market analysis pipeline...")
        
        if self.data is None or self.data.empty:
            logger.error("No data available for analysis")
            return
        
        # Run all analyses
        self.generate_market_overview()
        self.analyze_competition_landscape()
        self.identify_market_opportunities()
        self.generate_business_insights()
        
        # Create visualizations
        self.create_market_overview_chart()
        self.create_interactive_dashboard()
        
        # Save comprehensive report
        self.save_analysis_report()
        
        # Print summary
        self._print_analysis_summary()
        
        logger.info("Complete market analysis finished!")
    
    def _print_analysis_summary(self):
        """Print a summary of the analysis results"""
        print("\n" + "="*60)
        print("PUNE FITNESS MARKET ANALYSIS SUMMARY")
        print("="*60)
        
        if 'market_overview' in self.analysis_results:
            overview = self.analysis_results['market_overview']
            print(f"\n📊 MARKET OVERVIEW:")
            print(f"   • Total businesses identified: {overview['total_businesses']}")
            if overview['avg_rating']:
                print(f"   • Average rating: {overview['avg_rating']:.2f}/5.0")
            print(f"   • Data completeness: {overview['businesses_with_addresses']}/{overview['total_businesses']} have addresses")
        
        if 'competition' in self.analysis_results:
            competition = self.analysis_results['competition']
            if 'top_performers' in competition:
                print(f"\n🏆 TOP PERFORMERS:")
                for i, business in enumerate(competition['top_performers'][:3]):
                    print(f"   {i+1}. {business['business_name']} ({business['rating']:.1f}★)")
        
        if 'opportunities' in self.analysis_results:
            opportunities = self.analysis_results['opportunities']
            if 'underserved_categories' in opportunities:
                print(f"\n💡 MARKET OPPORTUNITIES:")
                for opp in opportunities['underserved_categories'][:3]:
                    print(f"   • {opp['category']}: {opp['market_share']:.1f}% market share")
        
        if 'insights' in self.analysis_results:
            insights = self.analysis_results['insights']
            print(f"\n🎯 KEY RECOMMENDATIONS:")
            for rec in insights['recommendations'][:3]:
                print(f"   • {rec}")
        
        print(f"\n📁 OUTPUTS GENERATED:")
        print(f"   • Market overview chart: data/output/market_overview.png")
        print(f"   • Interactive dashboard: data/output/interactive_dashboard.html")
        print(f"   • Analysis report: data/output/market_analysis_report.json")
        print("\n" + "="*60)

def main():
    """Example usage of the market analyzer"""
    
    # Look for the cleaned data file - prioritize comprehensive data files
    data_files = [
        'data/output/pune_comprehensive_market_data.csv', # Comprehensive generated data (752 records)
        'data/output/pune_enhanced_final.csv',         # Enhanced dataset with 575+ businesses
        'data/output/multi_source_comprehensive_data.csv', # Multi-source comprehensive data
        'data/processed/phase4_ultimate_cleaned.csv',
        'data/processed/cleaned_gym_data.csv',
        'data/output/pune_gyms_final.csv'             # Original smaller dataset (fallback only)
    ]
    
    data_file = None
    for file_path in data_files:
        if Path(file_path).exists():
            data_file = file_path
            logger.info(f"Using data file: {data_file}")
            break
    
    if not data_file:
        logger.error("No cleaned data file found. Please run data processing first.")
        return
    
    # Create analyzer and run complete analysis
    analyzer = FitnessMarketAnalyzer(data_file)
    analyzer.run_complete_analysis()

if __name__ == "__main__":
    main()